﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IC9_KS_LoopExercise
{
    public partial class Loop : Form
    {
        public Loop()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            numberTextBox.Clear();
            sumLabel.Text = "";
            productLabel.Text = "";
            numberTextBox.Focus();
        }

        private void sumLabel_Click(object sender, EventArgs e)
        {

        }

        private void sumButton_Click(object sender, EventArgs e)
        {
            //preppy
            int number;
            int sum = 0;

            //try parse
            if(!int.TryParse(numberTextBox.Text, out number)|| number < 0)

                for (int i = 0; i < length; i++)
                {
                    sum = sum + 1;
                }
        }
    }
}
